import React from 'react'
import style from './Copyrights.module.css'

function Copyrights() {
  return (
    <div className={style.Copyrights}>
      <p>© 2020 Suzuki Indonesia.</p> <p>All rights reserved.</p>
    </div>
  )
}

export default Copyrights
